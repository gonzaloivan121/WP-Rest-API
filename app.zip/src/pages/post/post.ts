import { Component } from '@angular/core';
import { NavParams, NavController, LoadingController, AlertController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { HomePage } from '../home/home';
import { WordpressService } from '../../services/wordpress.service';
import { AuthenticationService } from '../../services/authentication.service';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';


@Component({
  selector: 'page-post',
  templateUrl: 'post.html',
})
export class PostPage {

  post: any;
  user: string;
  comments: Array<any> = new Array<any>();
  categories: Array<any> = new Array<any>();
  img: string;
  morePagesAvailable: boolean = true;


  constructor(
    public navParams: NavParams,
    public navCtrl: NavController,    
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    public wpService: WordpressService,
    public authService: AuthenticationService
  ) {}


  ionViewWillEnter() {
    this.morePagesAvailable = true;
    let loading = this.loadingCtrl.create();

    loading.present();

    this.post = this.navParams.get('item');

    Observable.forkJoin(
      this.getAuthorData(),
      this.getCategories(),
      this.getComments())
      .subscribe(data => {
        this.user = data[0].name;
        this.categories = data[1];
        this.comments = data[2];
        loading.dismiss();
      });
  }


  getAuthorData() {
    return this.wpService.getAuthor(this.post.author);
  }


  getCategories() {
    return this.wpService.getPostCategories(this.post);
  }


  getComments() {
    return this.wpService.getComments(this.post.id);
  }


  loadMoreComments(infiniteScroll) {
    let page = (this.comments.length / 10) + 1;
    this.wpService.getComments(this.post.id, page)
    .subscribe(data => {
      for (let item of data) {
        this.comments.push(item);
      }
      infiniteScroll.complete();
    }, err => {
      console.log(err);
      this.morePagesAvailable = false;
    })
  }


  goToCategoryPosts(catId, catT) {
    this.navCtrl.push(HomePage, {
      id: catId,
      title: catT
    })
  }


  createComment(){
    let user: any;

    this.authService.getUser()
    .then(res => {
      user = res;

      let alert = this.alertCtrl.create({
      title: 'Añade un comentario',
      inputs: [
        {
          name: 'comment',
          placeholder: 'Comentario'
        }
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          handler: data => {
            console.log('Se ha cancelado el comentario');
          }
        },
        {
          text: 'Aceptar',
          handler: data => {
            let loading = this.loadingCtrl.create();
            loading.present();
            this.wpService.createComment(this.post.id, user, data.comment)
            .subscribe(
              (data) => {
                console.log("ok", data);
                this.getComments();
                loading.dismiss();
              },
              (err) => {
                console.log("error", err);
                loading.dismiss();
              }
            );
          }
        }
      ]
    });
    alert.present();
    },
    err => {
      let alert = this.alertCtrl.create({
        title: 'Inicia Sesión, por favor',
        message: 'Tienes que iniciar sesión para publicar un comentario.',
        buttons: [
          {
            text: 'Cancelar',
            role: 'cancel',
            handler: () => {
              console.log('Se ha cancelado el comentario');
            }
          },
          {
            text: 'Iniciar Sesión',
            handler: () => {
              this.navCtrl.push(LoginPage);
            }
          }
        ]
      });
    alert.present();
    });
  }

}