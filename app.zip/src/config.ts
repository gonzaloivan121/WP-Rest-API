//config constants
export const WORDPRESS_URL = 'http://192.168.1.111:8080/wordpress-gcb/';
export const WORDPRESS_REST_API_URL = WORDPRESS_URL + 'wp-json/wp/v2/';