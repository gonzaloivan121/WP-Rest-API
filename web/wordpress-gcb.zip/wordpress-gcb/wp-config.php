<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', 'wordpress');

/** Tu nombre de usuario de MySQL */
define('DB_USER', 'root');

/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', 'localhost');

/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8mb4');

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'Ps[@z7*QT=XF8#fI^3ya(!Yv`DP7/C@XJl1+x@L,mm,gyNu]ind6k,{bl,~&._o1');
define('SECURE_AUTH_KEY', 'r//}1f%`(jz5EWIRkH9~Ox07cwG&mVPt`m`(vv@Hj?t=*(a`t]XVd?Ite%i|Sg2$');
define('LOGGED_IN_KEY', '{Bb2x{qQJd5ns=}s?J7<FQ*M#8Yq-N2=At_R54Zg:u@WB%wMuw~C!(kQ9yJ(.J.g');
define('NONCE_KEY', 'TY<RB#xT1JQx7&IFoVC/Dx=A}TLS%7t=0$dW@B6xvUz/^K-*~N:W9u`4}[Pb33l{');
define('AUTH_SALT', '$cFw K$R7wJZ+DGm7_Z1oKdratm.C]H?8I$s9+[nbiZMb2~Hs>#=TU]s&O$&kjS ');
define('SECURE_AUTH_SALT', 'g()y!amG%[Mba)0c;6i)s;;g3jz>Qb9*IRU*3&cmiw*s_{g1ZB.X7M*@JK ,bY$Q');
define('LOGGED_IN_SALT', ' wsR@hYThK%+AQ@)PRd{[Mv?sl1~Wtu=^RU,[Oez#]R6)4(umYewJR$6UC9u,9qN');
define('NONCE_SALT', ';(<$my4WyiK.c#83E6eZ^-G<Wpay9+V1 jkVtWyqZk>JZYe$H{Px)7<=I~LFQ89T');

//CLAVE SECRETA PARA JWT AUTHENTIFICATION
define('JWT_AUTH_SECRET_KEY', '/eD.b,Cxa4=i4n>JaXH2hPn]Z(i(x9!W`v!r_&m8^L#M48#u=oB[~sSN,Lxg-u 7');
define('JWT_AUTH_CORS_ENABLE', true);

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'wp_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

